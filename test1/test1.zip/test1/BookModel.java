public class BookModel {
   public int bookID;
   public String title;
   public String author;
   public double pageNumbers;
   public double publicationYear;
}



